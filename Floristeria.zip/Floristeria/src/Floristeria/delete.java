package Floristeria;

public class delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa tomasCasa= new Casa("blanca con rojo",5,2,true,true);
		System.out.println(tomasCasa.describir());

	}

}
